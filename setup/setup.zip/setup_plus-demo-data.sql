-- phpMyAdmin SQL Dump
-- version 3.5.8.1deb1
-- http://www.phpmyadmin.net

-- DULEZITE:
-- 		Nasledujici skript vytvori strukturu DB a naplni ji ukazkovymi daty.
--		Uzivatele: 
--			admin: heslo "admin123"
--			test: heslo "test123"

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `objednavkovy-system`
--
-- --------------------------------------------------------
--
-- Table structure for table `actions`
--

CREATE TABLE IF NOT EXISTS `actions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_czech_ci NOT NULL,
  `description` text CHARACTER SET utf16 COLLATE utf16_czech_ci NOT NULL,
  `visible_from` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `visible_until` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `order_from` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `order_until` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `actions`
--

INSERT INTO `actions` (`id`, `name`, `description`, `visible_from`, `visible_until`, `order_from`, `order_until`) VALUES
(1, 'Prodej ovoce Dejvice', 'orem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus pellentesque gravida ipsum, vitae iaculis odio vestibulum vel. Sed eu quam eget eros feugiat pellentesque nec a enim. Cras nec ante porta, pellentesque ipsum a, gravida felis. Quisque lorem nibh, bibendum in placerat ac, placerat sed tellus. Aliquam consectetur risus vel quam elementum, id pretium diam facilisis. Aenean suscipit massa non congue molestie. Nullam quis magna non justo fringilla adipiscing et tincidunt metus. Pellentesque scelerisque urna vel ligula volutpat, id hendrerit libero hendrerit. Mauris faucibus urna sit amet augue pellentesque lacinia. Nulla placerat sapien orci. Nulla ac est neque. Etiam vitae tortor convallis, feugiat metus eu, pharetra sapien.', '2014-01-12 18:29:23', '2030-02-28 11:00:00', '2014-01-04 23:00:00', '2015-02-28 11:30:00'),
(2, 'Prodej ovoce Václavák', 'orem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus pellentesque gravida ipsum, vitae iaculis odio vestibulum vel. Sed eu quam eget eros feugiat pellentesque nec a enim. Cras nec ante porta, pellentesque ipsum a, gravida felis. Quisque lorem nibh, bibendum in placerat ac, placerat sed tellus. Aliquam consectetur risus vel quam elementum, id pretium diam facilisis. Aenean suscipit massa non congue molestie. Nullam quis magna non justo fringilla adipiscing et tincidunt metus. Pellentesque scelerisque urna vel ligula volutpat, id hendrerit libero hendrerit. Mauris faucibus urna sit amet augue pellentesque lacinia. Nulla placerat sapien orci. Nulla ac est neque. Etiam vitae tortor convallis, feugiat metus eu, pharetra sapien.', '2014-01-12 18:29:24', '2030-01-15 11:00:00', '2014-01-04 23:00:00', '2014-01-05 11:30:00'),
(3, 'Prodej ovoce Staromák', 'orem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus pellentesque gravida ipsum, vitae iaculis odio vestibulum vel. Sed eu quam eget eros feugiat pellentesque nec a enim. Cras nec ante porta, pellentesque ipsum a, gravida felis. Quisque lorem nibh, bibendum in placerat ac, placerat sed tellus. Aliquam consectetur risus vel quam elementum, id pretium diam facilisis. Aenean suscipit massa non congue molestie. Nullam quis magna non justo fringilla adipiscing et tincidunt metus. Pellentesque scelerisque urna vel ligula volutpat, id hendrerit libero hendrerit. Mauris faucibus urna sit amet augue pellentesque lacinia. Nulla placerat sapien orci. Nulla ac est neque. Etiam vitae tortor convallis, feugiat metus eu, pharetra sapien.', '2014-01-12 18:29:24', '2030-01-08 11:00:00', '2014-01-04 23:00:00', '2014-01-06 11:30:00');

-- --------------------------------------------------------

--
-- Table structure for table `actions_products`
--

CREATE TABLE IF NOT EXISTS `actions_products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `action_id_2` (`action_id`,`product_id`),
  KEY `product_id` (`product_id`),
  KEY `action_id` (`action_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci AUTO_INCREMENT=13 ;

--
-- Dumping data for table `actions_products`
--

INSERT INTO `actions_products` (`id`, `action_id`, `product_id`) VALUES
(9, 1, 1),
(5, 1, 2),
(2, 1, 3),
(10, 1, 7),
(11, 1, 8),
(12, 1, 9);

-- --------------------------------------------------------

--
-- Table structure for table `fetch_hours`
--

CREATE TABLE IF NOT EXISTS `fetch_hours` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `time_from` time NOT NULL,
  `time_until` time NOT NULL,
  `date` date NOT NULL,
  `action_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `action_id` (`action_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci AUTO_INCREMENT=18 ;

--
-- Dumping data for table `fetch_hours`
--

INSERT INTO `fetch_hours` (`id`, `time_from`, `time_until`, `date`, `action_id`) VALUES
(1, '12:00:00', '14:00:00', '2014-01-08', 1),
(2, '10:00:00', '16:00:00', '2014-01-09', 1),
(3, '08:00:00', '12:00:00', '2014-01-10', 1),
(4, '14:00:00', '18:00:00', '2014-01-10', 1),
(5, '08:00:00', '16:00:00', '2014-01-22', 1),
(8, '10:00:00', '12:30:00', '2014-01-27', 1),
(9, '13:30:00', '18:00:00', '2014-01-27', 1),
(10, '08:00:00', '14:00:00', '2014-01-30', 1),
(11, '09:00:00', '14:00:00', '2014-01-31', 1),
(12, '08:00:00', '12:00:00', '2014-02-03', 1),
(13, '14:00:00', '16:00:00', '2014-02-03', 1),
(14, '08:00:00', '12:00:00', '2014-02-07', 1),
(15, '14:00:00', '16:00:00', '2014-02-07', 1),
(16, '08:00:00', '12:00:00', '2014-02-17', 1),
(17, '14:00:00', '16:00:00', '2014-02-18', 1);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE IF NOT EXISTS `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fetch_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `note` text COLLATE utf8_czech_ci NOT NULL,
  `status` enum('accepted','canceled','done','new','pickedup') COLLATE utf8_czech_ci NOT NULL DEFAULT 'new',
  `prepared_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `picked_up_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_id` int(11) NOT NULL,
  `action_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `action_id` (`action_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci AUTO_INCREMENT=26 ;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `order_time`, `fetch_time`, `note`, `status`, `prepared_time`, `picked_up_time`, `user_id`, `action_id`) VALUES
(8, '2014-01-11 12:45:16', '2014-01-10 14:00:00', 'test', 'new', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 5, 1),
(9, '2014-01-11 12:45:16', '2014-01-10 14:00:00', 'test', 'new', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 5, 1),
(10, '2014-01-11 12:45:16', '2014-01-10 14:00:00', 'test', 'new', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 5, 1),
(11, '2014-01-11 12:45:16', '2014-01-10 14:00:00', 'test', 'new', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 5, 1),
(12, '2014-01-11 12:45:16', '2014-01-10 14:00:00', 'test', 'new', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 5, 1),
(13, '2014-01-11 12:45:16', '2014-01-10 14:00:00', 'test', 'new', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 5, 1),
(14, '2014-01-11 12:45:16', '2014-01-10 14:00:00', 'test', 'accepted', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 5, 1),
(15, '2014-01-11 12:45:16', '2014-01-10 14:00:00', 'test', 'accepted', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 5, 1),
(16, '2014-01-11 12:45:16', '2014-01-10 10:00:00', 'test', 'accepted', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 5, 1),
(17, '2014-01-11 12:45:16', '2014-01-10 14:00:00', 'test', 'accepted', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 5, 1),
(18, '2014-01-11 12:45:16', '2014-01-10 14:00:00', 'test', 'accepted', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 5, 1),
(19, '2014-01-11 12:45:16', '2014-01-10 14:59:00', 'test', 'accepted', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 5, 1),
(20, '2014-01-11 12:45:16', '2014-01-10 13:59:00', 'test', 'done', '2014-01-11 13:22:35', '0000-00-00 00:00:00', 5, 1),
(21, '2014-01-11 12:45:16', '2014-01-10 14:00:00', 'test', 'pickedup', '2014-01-11 13:11:11', '2014-01-11 13:11:48', 5, 1),
(22, '2014-01-11 12:45:16', '2014-01-10 13:00:00', 'test', 'pickedup', '2014-01-11 13:10:05', '2014-01-11 13:11:05', 5, 1),
(23, '2014-01-11 12:45:16', '2014-01-10 11:00:00', 'test', 'pickedup', '2014-01-11 12:52:04', '2014-01-11 12:52:15', 5, 1),
(24, '2014-01-11 12:50:30', '2014-01-27 13:00:00', 'test', 'pickedup', '2014-01-11 12:49:53', '2014-01-11 12:50:30', 5, 1),
(25, '2014-01-12 15:56:41', '2014-01-22 12:00:00', 'test', 'new', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 5, 1);

-- --------------------------------------------------------

--
-- Table structure for table `order_fields`
--

CREATE TABLE IF NOT EXISTS `order_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_czech_ci NOT NULL COMMENT 'Neni zabraneno zmene nazvu produktu, na ktery se odkazujeme, proto radeji z bezpecnostniho duvodu ukladame duplicitne nazev do db. Bylo by nevhodne po zmene nevedet nazev produktu v objednavce. Vedome poruseni zasad navrhu DB!',
  `count` mediumint(9) NOT NULL,
  `price_without_tax` int(11) NOT NULL,
  `vat` decimal(5,2) NOT NULL COMMENT 'Dan jako cislo z duvodu vetsi bezpecnosti uchovani spravne hodnoty. Vedome poruseni zasady navrhu DB.',
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`),
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci AUTO_INCREMENT=59 ;

--
-- Dumping data for table `order_fields`
--

INSERT INTO `order_fields` (`id`, `name`, `count`, `price_without_tax`, `vat`, `order_id`, `product_id`) VALUES
(5, 'Banán', 1, 34, 15.00, 8, 8),
(6, 'Mango', 1, 59, 15.00, 8, 8),
(7, 'Švestky', 1, 210, 21.00, 8, 8),
(8, 'kiwi', 4, 21, 15.00, 8, 8),
(9, 'Banán', 1, 34, 15.00, 9, 9),
(10, 'Mango', 1, 59, 15.00, 9, 9),
(11, 'Švestky', 1, 210, 21.00, 9, 9),
(12, 'kiwi', 4, 21, 15.00, 9, 9),
(13, 'Banán', 1, 34, 15.00, 10, 9),
(14, 'Mango', 1, 59, 15.00, 10, 7),
(15, 'Švestky', 1, 210, 21.00, 10, 3),
(16, 'kiwi', 4, 21, 15.00, 10, 1),
(17, 'Banán', 1, 34, 15.00, 11, 9),
(18, 'Mango', 1, 59, 15.00, 11, 7),
(19, 'Švestky', 1, 210, 21.00, 11, 3),
(20, 'kiwi', 4, 21, 15.00, 11, 1),
(21, 'Banán', 1, 34, 15.00, 12, 9),
(22, 'Mango', 1, 59, 15.00, 12, 7),
(23, 'Švestky', 1, 210, 21.00, 12, 3),
(24, 'kiwi', 4, 21, 15.00, 12, 1),
(25, 'Banán', 1, 34, 15.00, 13, 9),
(26, 'Mango', 1, 59, 15.00, 13, 7),
(27, 'Švestky', 1, 210, 21.00, 13, 3),
(28, 'kiwi', 4, 21, 15.00, 13, 1),
(29, 'Banán', 1, 34, 15.00, 14, 9),
(30, 'Mango', 1, 59, 15.00, 14, 7),
(31, 'Švestky', 1, 210, 21.00, 14, 3),
(32, 'kiwi', 4, 21, 15.00, 14, 1),
(33, 'Banán', 1, 34, 15.00, 15, 9),
(34, 'Mango', 1, 59, 15.00, 15, 7),
(35, 'Švestky', 1, 210, 21.00, 15, 3),
(36, 'kiwi', 4, 21, 15.00, 15, 1),
(37, 'Švestky', 1, 210, 21.00, 16, 3),
(38, 'pomeranč', 1, 100, 21.00, 17, 2),
(39, 'Mango', 2, 59, 15.00, 17, 7),
(40, 'Banán', 1, 34, 15.00, 17, 9),
(41, 'Mango', 1, 59, 15.00, 18, 7),
(42, 'Švestky', 1, 210, 21.00, 18, 3),
(43, 'Banán', 1, 34, 15.00, 19, 9),
(44, 'Švestky', 1, 210, 21.00, 20, 3),
(45, 'Švestky', 2, 210, 21.00, 21, 3),
(46, 'Mango', 1, 59, 15.00, 21, 7),
(47, 'Mango', 1, 59, 15.00, 22, 7),
(48, 'pomeranč', 1, 100, 21.00, 22, 2),
(49, 'Banán', 2, 34, 15.00, 22, 9),
(50, 'pomeranč', 2, 100, 21.00, 23, 2),
(51, 'Švestky', 1, 210, 21.00, 23, 3),
(52, 'Mango', 2, 59, 15.00, 23, 7),
(53, 'kiwi', 1, 21, 15.00, 23, 1),
(54, 'Banán', 1, 34, 15.00, 23, 9),
(55, 'Papája', 1, 87, 21.00, 23, 8),
(56, 'Švestky', 1, 210, 21.00, 24, 3),
(57, 'Mango', 2, 59, 15.00, 25, 7),
(58, 'pomeranč', 1, 100, 21.00, 25, 2);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE IF NOT EXISTS `products` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_czech_ci NOT NULL,
  `description` text COLLATE utf8_czech_ci NOT NULL,
  `price_without_tax` float NOT NULL,
  `min_order_time_hours` tinyint(3) unsigned DEFAULT NULL,
  `vat_id` int(10) unsigned NOT NULL,
  `min_order_time_days` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `vat_id` (`vat_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci AUTO_INCREMENT=10 ;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `description`, `price_without_tax`, `min_order_time_hours`, `vat_id`, `min_order_time_days`) VALUES
(1, 'kiwi', 'Kiwi, botanicky aktinídie lahodná čínský název: "Jang-Tao", je popínavá rostlina původem z Číny. Její ovoce obsahuje velké množství vitamínu C. Velikostí je podobné slepičímu vejci, slupka je hnědá a chlupatá, dužina obvykle zelená', 21, 12, 2, 1),
(2, 'pomeranč', 'Ovoce s oranžovou šlupkou a sladkokyselou dužinou plnou vitamínu C.', 100, 255, 1, 0),
(3, 'Švestky', 'dasdas d sa das d sa ', 210, 1, 1, 0),
(7, 'Mango', 'Mango je tropické ovoce, plod mangovníku. Mango patří do rodu Mangifera, který zahrnuje 69 botanických druhů a přes 1000 odrůd tohoto ovoce. Není znám jeho přesný původ, ale má se za to, že mango pochází z jižní a jihovýchodní Asie. (přejato: wikipedie)', 59, 6, 2, 0),
(8, 'Papája', 'Papája je rod teplomilných rostlin z čeledě papájovitých, vyznačující se velkými jedlými plody. Tento monotypický rod obsahuje pouze jeden druh Papája obecná. (přejato: wikipedie)', 87, 12, 1, 4),
(9, 'Banán', 'Banán je protáhlé ovoce a plod banánovníku. Jde o velice žádanou komoditou produkovanou zemědělci tropických zemí, kde tvoří významnou složku potravy. (přejato: wikipedie)', 34, 0, 2, 3);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(64) COLLATE utf8_czech_ci NOT NULL,
  `lastname` varchar(64) COLLATE utf8_czech_ci NOT NULL,
  `username` varchar(32) COLLATE utf8_czech_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_czech_ci NOT NULL,
  `email` varchar(128) COLLATE utf8_czech_ci NOT NULL,
  `phone` varchar(16) COLLATE utf8_czech_ci NOT NULL,
  `city` varchar(64) COLLATE utf8_czech_ci NOT NULL,
  `role` enum('admin','customer','','') COLLATE utf8_czech_ci NOT NULL DEFAULT 'customer',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci AUTO_INCREMENT=6 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `firstname`, `lastname`, `username`, `password`, `email`, `phone`, `city`, `role`) VALUES
(4, 'Administrátor', 'xx', 'admin', '$2a$07$b40vutjrl4acwvistuanxuTXsMxCPtn/wTPv6nmsNJi0UMChCaWZC', 'admin@local.host', '123456789', 'xx', 'admin'),
(5, 'Test', 'xx', 'test', '$2a$07$8xzcihjpb59tfweciq741uycrwB3EIkaapVTfYvNsahrSQn8bqF9G', 'test@local.host', '123456789', 'xx', 'customer');

-- --------------------------------------------------------

--
-- Table structure for table `vats`
--

CREATE TABLE IF NOT EXISTS `vats` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) CHARACTER SET latin1 DEFAULT NULL,
  `value` decimal(5,2) DEFAULT NULL,
  `default` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `vats`
--

INSERT INTO `vats` (`id`, `name`, `value`, `default`) VALUES
(1, 'Základní DPH 21%', 21.00, 0),
(2, 'Snížená sazba DPH 15%', 15.00, 1);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `actions_products`
--
ALTER TABLE `actions_products`
  ADD CONSTRAINT `actions_products_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `actions_products_ibfk_1` FOREIGN KEY (`action_id`) REFERENCES `actions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `fetch_hours`
--
ALTER TABLE `fetch_hours`
  ADD CONSTRAINT `fetch_hours_ibfk_1` FOREIGN KEY (`action_id`) REFERENCES `actions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`action_id`) REFERENCES `actions` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `orders_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `order_fields`
--
ALTER TABLE `order_fields`
  ADD CONSTRAINT `order_fields_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `order_fields_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`vat_id`) REFERENCES `vats` (`id`) ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
